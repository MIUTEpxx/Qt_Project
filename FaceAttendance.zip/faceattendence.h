#ifndef FACEATTENDENCE_H
#define FACEATTENDENCE_H

#include <opencv.hpp>
#include <QMainWindow>
#include <QTcpSocket>
#include <QTimer>
#include<QMessageBox>
using namespace cv;
using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class faceattendence; }
QT_END_NAMESPACE

class faceattendence : public QMainWindow
{
    Q_OBJECT

public:
    faceattendence(QWidget *parent = nullptr);
    ~faceattendence();
    //定时器事件->摄像头实时显示
    void timerEvent(QTimerEvent *e);

private slots:
    void timer_connect();//定时连接服务器
    void stop_connect();//断开连接
    void start_connect();//开始连接
    void recv_data();//接受服务器端发来的数据
    void clear_ui();//清空ui上的数据
private:
    Ui::faceattendence *ui;

    int timeID1;//传输数据的时间事件ID
    int flag_onepersion;//检测次数标签 大于零表示检测到人脸
    //摄像头
    VideoCapture cap;
    //hear--级联分类器对象
    cv::CascadeClassifier cascade;
    cv::CascadeClassifier eyeCascade;
    cv::CascadeClassifier leftEyeCascade;
    cv::CascadeClassifier rightEyeCascade;
    //创建网络套接字,定时器
    QTcpSocket msocket;
    QTimer mtimer;
};
#endif // FACEATTENDENCE_H
