#include "faceattendence.h"

#include <QApplication>
#include <QDir>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    faceattendence w;
    // 获取当前目录
    QDir currentDir = QDir::current();
    // 创建名为 "data" 的文件夹
    if (!currentDir.exists("data")) {
        if (!currentDir.mkdir("data")) {
            qDebug() << "创建data文件夹失败,请手动创建";
            return -1;
        } else {
            qDebug() << "data文件夹创建成功";
        }
    }
    w.show();
    return a.exec();
}
