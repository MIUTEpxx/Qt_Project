#include "faceattendence.h"
#include "ui_faceattendence.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonParseError>
#include <QFile>
#include <QByteArray>
#include <QDir>


faceattendence::faceattendence(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::faceattendence)
{

    flag_onepersion=0;

    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/res/FaceAttendance_Logo"));//设置图标

    ui->headpicLb->setVisible(false);
    ui->ReyepicLb->setVisible(false);
    ui->LeyepicLb->setVisible(false);
    ui->wg_success->hide();
    //打开摄像头
    //cap.open(0);//dev/video
    cap.open(0);
    //启动定时器事件
    startTimer(100);//100ms启动一次 读取一帧摄像头画面
    timeID1=startTimer(1000);//1000进行一次传输数据

    //导入级联分类器文件
//    eyeCascade.load("D:/MIUTE/Project1/opencv452/etc/haarcascades/haarcascade_eye.xml");
//    cascade.load("D:/MIUTE/Project1/opencv452/etc/haarcascades/haarcascade_frontalface_alt2.xml");
//    leftEyeCascade.load("D:/MIUTE/Project1/opencv452/etc/haarcascades/haarcascade_lefteye_2splits.xml");
//    rightEyeCascade.load("D:/MIUTE/Project1/opencv452/etc/haarcascades/haarcascade_righteye_2splits.xml");
        qDebug()<<PRO_FILE_PATH;//pro文件的路径
        eyeCascade.load(PRO_FILE_PATH"/opencv452/etc/haarcascades/haarcascade_eye.xml");
        cascade.load(PRO_FILE_PATH"./opencv452/etc/haarcascades/haarcascade_frontalface_alt2.xml");
        leftEyeCascade.load(PRO_FILE_PATH"./opencv452/etc/haarcascades/haarcascade_lefteye_2splits.xml");
        rightEyeCascade.load(PRO_FILE_PATH"./opencv452/etc/haarcascades/haarcascade_righteye_2splits.xml");

    //当QTcpSocket当断开连接的时候disconnected信号,连接成功会发送connected
    connect(&msocket,&QTcpSocket::disconnected,this,&faceattendence::start_connect);
    connect(&msocket,&QTcpSocket::connected,this,&faceattendence::stop_connect);

    //关联接受数据的槽函数
    connect(&msocket,&QTcpSocket::readyRead,this,&faceattendence::recv_data);

    //定时连接服务器
    connect(&mtimer,&QTimer::timeout,this,&faceattendence::timer_connect);

    //启动定时器
    mtimer.start(5000);//每5s连接一次，直到连接成功

}

faceattendence::~faceattendence()
{
    delete ui;
}

void faceattendence::timerEvent(QTimerEvent *e)
{
    //采集数据
    Mat srcImage;
    if(cap.grab())
    {
        cap.read(srcImage);//读取一帧
    }
    //把图片大小设置与窗口一样大
    cv::resize(srcImage,srcImage,Size(480,480));

    cv::flip(srcImage, srcImage, 1); // 水平翻转图像，因为摄像头的图像可能是镜像的

    //为提升检测速度，将图片转为灰度图
    Mat grayImage;
    cvtColor(srcImage,grayImage,COLOR_BGR2GRAY);
    //equalizeHist(grayImage, grayImage);
    //检测人脸数据
    std::vector<Rect> faceRects;
    cascade.detectMultiScale(grayImage,faceRects);//各参数含义请参考文档
    if(faceRects.size()>0&& flag_onepersion >=0){//检测到人脸

       Rect rect=faceRects.at(0);//第一个人脸的矩形框
       //rectangle(srcImage,rect,Scalar(255,0,0));//对检测到人脸的位置(rect)绘制一个矩形框
       ui->headpicLb->setVisible(true);
       ui->headpicLb->resize(rect.width, rect.height);
       ui->headpicLb->move(rect.x,rect.y);
       ///////////////////////////////////////////////////
       cv::Mat faceROI = grayImage(faceRects[0]);
       std::vector<cv::Rect> eyes;
       leftEyeCascade.detectMultiScale(faceROI, eyes);
       rightEyeCascade.detectMultiScale(faceROI, eyes);
       for (size_t j = 0; j < eyes.size()&&j<2; j++) {
           cv::Rect eyeRect = eyes[j];
           eyeRect.x += rect.x;
           eyeRect.y += rect.y;
           //rectangle(srcImage, eyeRect, cv::Scalar(0, 0, 255)); // 画眼睛矩形框
           if(j==0){
               ui->ReyepicLb->setVisible(true);
               ui->ReyepicLb->resize(eyeRect.width, eyeRect.height);
               ui->ReyepicLb->move(eyeRect.x,eyeRect.y);
            }else{
               ui->LeyepicLb->setVisible(true);
               ui->LeyepicLb->resize(eyeRect.width, eyeRect.height);
               ui->LeyepicLb->move(eyeRect.x,eyeRect.y);
           }
        }

       // 添加眨眼检测逻辑
        //待实现

       ////////////////////////////////////////////////////
       if(e->timerId()==timeID1&&flag_onepersion>2){
           //把Mat矩阵数据转化为QbyteArray数据 来发送至服务器端 利用cv::imencode编码成jpg格式
           std::vector<uchar> buf;//输出的字节流，即编码后的图像数据将被存储在这个向量中
           cv::imencode(".jpg",srcImage,buf);//详见函数说明
           QByteArray byte((const char*)buf.data(),buf.size());
           //准备发送
           quint64 backsize =byte.size();// 获取数据大小
           QByteArray sendData; // 创建用于发送数据的 QByteArray 对象
           QDataStream stream(&sendData,QIODevice::WriteOnly);// 创建 QDataStream 对象，用于将数据写入 sendData
           stream.setVersion(QDataStream::Qt_5_14); // 设置 QDataStream 的版本
           stream<<backsize<<byte;// 将数据大小和字节数据写入 sendData
           // 将数据发送给客户端
           msocket.write(sendData);
           flag_onepersion = -2;
       }
       flag_onepersion++;
    }
    else{
       // ui->headpicLb->move(107,30);
        ui->headpicLb->setVisible(false);
        ui->ReyepicLb->setVisible(false);
        ui->LeyepicLb->setVisible(false);
        flag_onepersion = 0;
    }
    if(srcImage.data==nullptr) return;

    //把opencv里面的Mat格式数据(BGR)转化Qt里面的QImage(RGB)
    cvtColor(srcImage,srcImage,COLOR_BGRA2BGR);
    QImage image(srcImage.data,srcImage.cols,srcImage.rows,srcImage.step1(),QImage::Format_BGR888);
    QPixmap mmp = QPixmap::fromImage(image);

    mmp=mmp.scaledToWidth(ui->videoLb->width());
    ui->videoLb->setPixmap(mmp);
}

void faceattendence::timer_connect()
{
    //连接服务器
    //msocket.connectToHost("192.168.137.1",9999);
//    msocket.connectToHost("192.168.35.1",9999);
//    qDebug()<<"正在连接服务器";
    // 使用 PRO_FILE_PATH 定义文件路径
        QString filePath = QString(PRO_FILE_PATH) + "/IP.txt";
        QFile file(filePath);
        QString ip;

        // 检查文件是否存在
        if (!file.exists()) {
            // 文件不存在，创建并写入默认 IP
            if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
                QTextStream out(&file);
                out << "192.168.137.1";
                file.close();
                ip = "192.168.137.1";
            } else {
                // 无法创建文件，处理错误
                qWarning() << "无法创建文件" << filePath;
                return;
            }
        } else {
            // 文件存在，读取 IP
            if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
                QTextStream in(&file);
                ip = in.readLine();
                file.close();
            } else {
                // 无法读取文件，处理错误
                qWarning() << "无法读取文件" << filePath;
                return;
            }
        }

        // 使用读取或写入的 IP 进行连接
        msocket.connectToHost(ip, 9999);
        qDebug()<<"正在连接服务器";
        ui->label_connect->setText("未连接服务器端");
}

void faceattendence::stop_connect()
{
    mtimer.stop();
     qDebug()<<"成功连接服务器";
     ui->label_connect->setText("已连接服务器端");
}

void faceattendence::start_connect()
{
    mtimer.start(5000);//启动定时器
    qDebug()<<"断开连接";
    ui->label_connect->setText("未连接服务器端");
}
bool flag=true;


void faceattendence::recv_data()
{

    /*
    QString msg = msocket.readAll();
    qDebug()<<msg;
    ui->lineEdit->setText(msg);
    */
    //接受数据并展示
    QByteArray array=msocket.readAll();//读取所有传来的数据
    //JSON解析
    QJsonParseError err;
    QJsonDocument doc = QJsonDocument::fromJson(array, &err);

    if(err.error != QJsonParseError::NoError){
        qDebug()<<"___Json格式错误: "<< err.errorString();
        //QMessageBox::warning(this,"错误","Json格式错误");
        return;
    }
    // 获取JSON对象
    QJsonObject obj = doc.object();
    // 获取所有的键
    QJsonObject::const_iterator iter = obj.constBegin();
    QVector<QPair<QString,QString>> data;

    while (iter != obj.constEnd()) {
        // 获取键
        QString key = iter.key();
        // 获取值
        QJsonValue value = iter.value();
        if (value.isString()) {
//            data[i] = value.toString();
//            qDebug() << key << ": " << value.toString();
            data.append({key,value.toString()});
        }
         ++iter;
    }
    sort(data.begin(), data.end());//对数据进行排序 使其与发送时的顺序一致

//    QString faceid  = obj.value("faceid").toString();
//    QString base64String = obj["image"].toString(); // 获取Base64编码的图片数据
    QString faceid  = data[4].second;       //获取faceID
    QString base64String = data[5].second; // 获取Base64编码的图片数据
    QString attendanceStatus = data[6].second;//获取考勤状态

    // 更新界面显示
    qDebug()<<"faceID="<<faceid;
    qDebug()<<"attendanceStatus "<<attendanceStatus;
    if (faceid == "-1") {
        // 未识别出人脸
        ui->lineEdit_id->setText("该人脸未登记");
        ui->headLb->setStyleSheet("");
        return;
    }

    if(attendanceStatus=="0") ui->statusLb->setText("已成功打卡");
    else if(attendanceStatus=="1") ui->statusLb->setText("今日已打卡");
    else ui->statusLb->setText("打卡失败");

    if(flag){
        flag=false;
        ui->lineEdit_id->setText(data[0].second);  // 员工ID
        ui->lineEdit_name->setText(data[1].second);          // 姓名
        ui->lineEdit_department->setText(data[2].second);        // 部门
        ui->lineEdit_time->setText(data[3].second);      // 时间
        //接收图片数据
        // 将QString转换为QByteArray
        QByteArray imageData = base64String.toLocal8Bit();
        // 解码Base64编码的图片数据
        //QByteArray decodedImageData = QByteArray::fromBase64(imageData);
        QByteArray decodedImageData = QByteArray::fromBase64(base64String.toLocal8Bit());
        //qDebug()<<"______图像数据：\n"<<decodedImageData;
        // 保存图片到文件，覆盖已存在的文件
        QString headfile = "./data/image.jpg";
        QFile file(headfile);
        if (file.open(QIODevice::WriteOnly)) {
            file.write(decodedImageData);
            file.close();

            // 更新UI显示图片
            ui->headLb->setStyleSheet(QString("QLabel { border-image: url(%1) 0 0 0 0 stretch stretch; }").arg(headfile));
        } else {
            qDebug() << "Unable to save image file:" << headfile;
        }

        ui->wg_success->show();
        QTimer::singleShot(2000, this, &faceattendence::clear_ui); // 2秒钟后调用槽函数 清楚ui数据
       // qDebug()<<flag;
    }

}
void faceattendence::clear_ui()
{
    ui->lineEdit_id->setText("0");  // 员工ID
    ui->lineEdit_name->setText("0");          // 姓名
    ui->lineEdit_department->setText("0");        // 部门
    ui->lineEdit_time->setText("0");      // 时间
    ui->headLb->setStyleSheet("");
    ui->wg_success->hide();
    flag=true;
}

#if 0
void faceattendence::recv_data()
{

    /*
    QString msg = msocket.readAll();
    qDebug()<<msg;
    ui->lineEdit->setText(msg);
    */
    //接受数据并展示
    QByteArray array=msocket.readAll();//读取所有传来的数据
    //JSON解析
    QJsonParseError err;
    QJsonDocument doc = QJsonDocument::fromJson(array, &err);

    if(err.error != QJsonParseError::NoError){
        qDebug()<<"___Json格式错误: "<< err.errorString();
        //QMessageBox::warning(this,"错误","Json格式错误");
        return;
    }

    // 获取JSON对象
    QJsonObject obj = doc.object();
    //{"employeeID":%1,"name":%2,"department":"软件","time":%3}
    // 获取员工ID、姓名、时间和地址信息
    QString employeeID = obj.value("employeeID").toString(); // 员工ID
    QString name = obj.value("name").toString();             // 姓名
    QString timestr = obj.value("time").toString();          // 时间字符串
    QString address = obj.value("department").toString();       // 部门
    QString faceid  = obj.value("faceid").toString();
    QString base64String = obj["image"].toString(); // 获取Base64编码的图片数据
    // 更新界面显示
    qDebug()<<faceid;

    if (faceid == "-1") {
        // 未识别出人脸
        ui->headLb->setStyleSheet("");
        return;
    }

    //接收图片数据
#if 1
    // 将QString转换为QByteArray
    QByteArray imageData = base64String.toLocal8Bit();
    // 解码Base64编码的图片数据
    //QByteArray decodedImageData = QByteArray::fromBase64(imageData);
    QByteArray decodedImageData = QByteArray::fromBase64(base64String.toLocal8Bit());
    qDebug()<<"______图像数据：\n"<<decodedImageData;
    // 保存图片到文件，覆盖已存在的文件
    QString headfile = "./data/image.jpg";
    QFile file(headfile);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(decodedImageData);
        file.close();

        // 更新UI显示图片
        ui->headLb->setStyleSheet(QString("QLabel { border-image: url(%1) 0 0 0 0 stretch stretch; }").arg(headfile));
    } else {
        qDebug() << "Unable to save image file:" << headfile;
    }
#endif
    if(flag){
        flag=false;
        ui->lineEdit_id->setText(employeeID);  // 员工ID
        ui->lineEdit_name->setText(name);          // 姓名
        ui->lineEdit_department->setText(address);        // 部门
        ui->lineEdit_time->setText(timestr);      // 时间
#if 0

    QString headfile = QString("D:/MIUTE/Project1/test/build-AttendanceServer-Desktop_Qt_5_14_2_MinGW_64_bit-Debug/data/%1.jpg").arg(faceid);
    // 检查文件是否存在
    if (QFile::exists(headfile)) {
            ui->headLb->setStyleSheet(QString("QLabel { border-image: url(%1) 0 0 0 0 stretch stretch; }").arg(headfile));

    } else {
        qDebug() << "Image file does not exist:" << headfile;
    }
#endif
    ui->wg_success->show();


        QTimer::singleShot(2000, this, &faceattendence::clear_ui); // 2秒钟后调用槽函数
       // qDebug()<<flag;
    }

}
#endif

#if 0
void faceattendence::recv_data()
{

    /*
    QString msg = msocket.readAll();
    qDebug()<<msg;
    ui->lineEdit->setText(msg);
    */
    //接受数据并展示
    QByteArray array=msocket.readAll();//读取所有传来的数据
    //JSON解析
    QJsonParseError err;
    QJsonDocument doc = QJsonDocument::fromJson(array, &err);

    if(err.error != QJsonParseError::NoError){
        qDebug()<<"___Json格式错误: "<< err.errorString();
        //QMessageBox::warning(this,"错误","Json格式错误");
        return;
    }

    // 获取JSON对象
    QJsonObject obj = doc.object();
    //{"employeeID":%1,"name":%2,"department":"软件","time":%3}
    // 获取员工ID、姓名、时间和地址信息
    QString employeeID = obj.value("employeeID").toString(); // 员工ID
    QString name = obj.value("name").toString();             // 姓名
    QString timestr = obj.value("time").toString();          // 时间字符串
    QString address = obj.value("department").toString();       // 部门
    QString faceid  = obj.value("faceid").toString();
    QString base64String = obj["image"].toString(); // 获取Base64编码的图片数据
    // 更新界面显示
    qDebug()<<faceid;

    if (faceid == "-1") {
        // 未识别出人脸
        ui->lineEdit_id->setText("该人脸未登记");
        ui->headLb->setStyleSheet("");
        return;
    }

    if(flag){
        flag=false;
        ui->lineEdit_id->setText(employeeID);  // 员工ID
        ui->lineEdit_name->setText(name);          // 姓名
        ui->lineEdit_department->setText(address);        // 部门
        ui->lineEdit_time->setText(timestr);      // 时间
        //接收图片数据
        // 将QString转换为QByteArray
        QByteArray imageData = base64String.toLocal8Bit();
        // 解码Base64编码的图片数据
        //QByteArray decodedImageData = QByteArray::fromBase64(imageData);
        QByteArray decodedImageData = QByteArray::fromBase64(base64String.toLocal8Bit());
        qDebug()<<"______图像数据：\n"<<decodedImageData;
        // 保存图片到文件，覆盖已存在的文件
        QString headfile = "./data/image.jpg";
        QFile file(headfile);
        if (file.open(QIODevice::WriteOnly)) {
            file.write(decodedImageData);
            file.close();

            // 更新UI显示图片
            ui->headLb->setStyleSheet(QString("QLabel { border-image: url(%1) 0 0 0 0 stretch stretch; }").arg(headfile));
        } else {
            qDebug() << "Unable to save image file:" << headfile;
        }

        ui->wg_success->show();

        QTimer::singleShot(2000, this, &faceattendence::clear_ui); // 2秒钟后调用槽函数 清楚ui数据
       // qDebug()<<flag;
    }

}
#endif
