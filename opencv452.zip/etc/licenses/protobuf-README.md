Project: Protocol Buffers - Google's data interchange format
Source code: https://github.com/protocolbuffers/protobuf
Version: 3.5.2
