#include "test_registerwin.h"
#include "ui_test_registerwin.h"
#include <QLabel>
#include <QPushButton>
#include <QLineEdit>
#include <QVBoxLayout>
#include <QHBoxLayout>

test_registerwin::test_registerwin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::test_registerwin)
{
    ui->setupUi(this);
    // 断开自动生成的连接 确保connect(ui->registerBtn,&QPushButton::clicked,[=](){});优先执行
    disconnect(ui->registerBtn, nullptr, this, nullptr);
    initdata();
    // 重新连接自动生成的槽函数
    connect(ui->registerBtn, &QPushButton::clicked, this, &test_registerwin::on_registerBtn_clicked);
}

test_registerwin::~test_registerwin()
{
    delete ui;
}

void test_registerwin::initdata()
{
    //2.把个人信息存储到数据库employee
    model.setTable("employee");//设置表名
    record=model.record();

    QSqlQuery query;
    query.prepare("PRAGMA table_info(employee)");
    if (!query.exec()) {
        qDebug() << "Error retrieving table information:" << query.lastError().text();
        return;
    }

    // 使用 QStringList 来存储列名
    QStringList columnNames;
    int columnCount = 0;
    QWidget *contentWidget = new QWidget(); // QScrollArea 的中心控件
    QVBoxLayout *mainLayout = new QVBoxLayout(contentWidget); // 主垂直布局


    //设置数据

    // 遍历查询结果，获取列信息
    int i=0;
    while (query.next()) {
        QString columnName = query.value("name").toString();
        columnNames.append(columnName);
        columnCount++;
        QHBoxLayout *layout1 = new QHBoxLayout();
        QLabel *label1 = new QLabel(columnName);
        QLineEdit *lineEdit1 = new QLineEdit();
        layout1->addWidget(label1);
        layout1->addWidget(lineEdit1);
        mainLayout->addLayout(layout1); // 将水平布局添加到主垂直布局中

        connect(ui->registerBtn,&QPushButton::clicked,[=](){
           record.setValue(columnName,lineEdit1->text());
           data.append({columnNames[i],lineEdit1->text()});
          //qDebug()<<columnNames[i]<<" "<<lineEdit1->text();
        });

        connect(ui->resetBtn,&QPushButton::clicked,[=](){
           lineEdit1->clear();
        });
        i++;
    }
    // 设置 QScrollArea 的中心控件
    ui->scrollArea->setWidget(contentWidget);

}

void test_registerwin::on_registerBtn_clicked()
{
    for(QPair<QString,QString> a:data){
        qDebug()<<a.first<<" "<<a.second;
    }
}
