#include "sqlform.h"
#include "ui_sqlform.h"


SQLForm::SQLForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SQLForm)
{
    ui->setupUi(this);
    iniData();//初始化
}

SQLForm::~SQLForm()
{
    delete ui;
}
void SQLForm::iniData()
{
    m_strings.clear();
    ui->lineEdit->clear();
    ui->listWidget->clear();

    headstr="create table if not exists new_employee(";
    tailstr="faceID integer unique,headFile text)";

    headstr0="create table if not exists new_attendance(attendanceID integer primary key autoincrement,";
    tailstr0="attendanceTime TIMESTAMP NOT NULL DEFAULT(datetime('now', 'localtime')))";

}
void SQLForm::moveFile()
{

    // 删除当前目录下的 face.db 已注册的人脸数据文件
    QString filePath = "face.db";
    QString dirName = "data";
    QFile file(filePath);
    if (file.exists()) {
        if (file.remove()) {
            qDebug() << "文件删除成功";
        } else {
            qDebug() << "文件删除失败：" << file.errorString();
        }
    } else {
        qDebug() << "文件不存在";
    }
    QDir dir(dirName);
        if (!dir.exists()) {
            // 目录不存在，返回错误
            return;
        }

        // 获取目录中的所有文件和文件夹
        QFileInfoList fileList = dir.entryInfoList(QDir::NoDotAndDotDot | QDir::Files | QDir::Hidden | QDir::System);
        for (int i = 0; i < fileList.size(); ++i) {
            QFileInfo fileInfo = fileList.at(i);
            if (fileInfo.isFile()) {
                // 删除文件
                if (!dir.remove(fileInfo.fileName())) {
                    // 删除文件失败，返回错误
                    return;
                }
            }
        }

}



void SQLForm::on_pushButton_clicked()
{
    QString text = ui->lineEdit->text();
    if (!text.isEmpty()) {
        if(QMessageBox::question(this,"",QString("确认插入项: %1 ？").arg(text),
                                 QMessageBox::Ok|QMessageBox::No)==QMessageBox::No) {return;}
        m_strings.append(text);
        QListWidgetItem *item = new QListWidgetItem(text);
        ui->listWidget->addItem(item);
    }
}


void SQLForm::on_listWidget_itemClicked(QListWidgetItem *item)
{
    if (ui->listWidget->selectedItems().isEmpty()) return;
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "删除", "你确定要删除这个项目吗？",
                                  QMessageBox::Yes|QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        item = ui->listWidget->selectedItems().first();
        QString text = item->text();
        ui->listWidget->takeItem(ui->listWidget->row(item));
        m_strings.removeAll(text);
    }

}

void SQLForm::on_pushButton_2_clicked()
{
    int size=m_strings.size();
    if(size==0){
        QMessageBox::warning(this,"警告","数据库的项不能为空",QMessageBox::Ok);
        return;
    }else{
      if(QMessageBox::information(this,"创建新数据库",
                                 "将会移除原有数据库以创建新数据库\n确定进行此操作?",
                                 QMessageBox::Ok|QMessageBox::No)==QMessageBox::No)
      {return;}else{moveFile();}//将原来的旧数据库移动至文件夹"old_data_base"中

    }
    for(int i=0;i<size;i++){
        QString str;
        if(i==0) str=m_strings[i]+ QString(" varchar(32) primary key,");
        else str=m_strings[i]+ QString(" varchar(32),");
        headstr+=str;
    }
    for(int i=0;i<size&&i<3;i++){//只取前三项信息
        headstr0+=m_strings[i]+ QString(" varchar(32),");
    }
    QString createsql=headstr+tailstr;
    qDebug()<<createsql;


    QSqlQuery query;
    if(!query.exec(createsql)){
        qDebug()<<222<<query.lastError().text()<<222;//输出错误信息
        return;
    }
    //创建考勤表
    createsql=headstr0+tailstr0;
   if(!query.exec(createsql)){
        qDebug()<<333<<query.lastError().text()<<333;//输出错误信息
        return;
    }
   // 删除旧表
   query.prepare("DROP TABLE IF EXISTS employee");
   if (!query.exec()) {
       qDebug() << "Error dropping old employee table:" << query.lastError().text();
       return;
   }

   query.prepare("DROP TABLE IF EXISTS attendance");
   if (!query.exec()) {
       qDebug() << "Error dropping old attendance table:" << query.lastError().text();
       return;
   }
   // 重命名新表为旧表名
   query.prepare("ALTER TABLE new_employee RENAME TO employee");
   if (!query.exec()) {
       qDebug() << "Error renaming new employee table:" << query.lastError().text();
       return;
   }

   query.prepare("ALTER TABLE new_attendance RENAME TO attendance");
   if (!query.exec()) {
       qDebug() << "Error renaming new attendance table:" << query.lastError().text();
       return;
   }
   iniData();//初始化数据
   emit sqlChange();//发送信号，告知数据库已更改
}

void SQLForm::on_pushButton_3_clicked()
{
    iniData();
}
