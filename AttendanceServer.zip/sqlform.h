#ifndef SQLFORM_H
#define SQLFORM_H

#include <QWidget>
#include <QListWidgetItem>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QMessageBox>
#include <QDebug>
#include<QSqlDatabase>//使用qt自带数据库QSQLITE
#include<QSqlError>//用于数据库排查错误
#include<QSqlQuery>//数据库查询

namespace Ui {
class SQLForm;
}

class SQLForm : public QWidget
{
    Q_OBJECT

public:
    explicit SQLForm(QWidget *parent = nullptr);
    ~SQLForm();

    void moveFile();
    void iniData();
private slots:
    void on_pushButton_clicked();

   // void on_listWidget_itemSelectionChanged();

    void on_listWidget_itemClicked(QListWidgetItem *item);

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::SQLForm *ui;
    QStringList m_strings;
    QString headstr,tailstr;
    QString headstr0,tailstr0;
    QSqlDatabase db;
signals:
    void sqlChange();
};

#endif // SQLFORM_H
