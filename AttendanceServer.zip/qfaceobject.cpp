#include "qfaceobject.h"
#include <QDebug>
QFaceObject::QFaceObject(QObject *parent) : QObject(parent)
{
  Load();
}

QFaceObject::~QFaceObject()
{
    delete fengineptr;
}
void QFaceObject::reLoad()
{
    //重新导入face数据库
    this->fengineptr->Load("./face.db");
}

void QFaceObject::Load()
{
    // 初始化 seeta 人脸引擎设置
    seeta::ModelSetting FDmode("D:/MIUTE/Project1/SeetaFace/bin/model/fd_2_00.dat",seeta::ModelSetting::CPU,0);
    seeta::ModelSetting PDmode("D:/MIUTE/Project1/SeetaFace/bin/model/pd_2_00_pts5.dat",seeta::ModelSetting::CPU,0);
    seeta::ModelSetting FRmode("D:/MIUTE/Project1/SeetaFace/bin/model/fr_2_10.dat",seeta::ModelSetting::CPU,0);
    // 创建 seeta 人脸引擎对象
    this->fengineptr = new seeta::FaceEngine(FDmode,PDmode,FRmode);
    //导入face数据库
    this->fengineptr->Load("./face.db");
}
int64_t QFaceObject::face_register(cv::Mat &faceImage)//注册人脸
{
    //把opencv的Mat数据转为seetaface的数据
    SeetaImageData simage;
    simage.data=faceImage.data;
    simage.width=faceImage.cols;
    simage.height=faceImage.rows;
    simage.channels=faceImage.channels();
    ///先检验该人脸是否已被注册///
    // 声明相似度变量
    float similarity=0;
    // 调用人脸引擎进行人脸识别
    int64_t faceID =fengineptr->Query(simage,&similarity);
    //如果人脸可信度大于0.6 说明已经被注册
    if(similarity>=0.6){
         return -1;
    }else{
        ///注册该人脸///
        int64_t faceid = this->fengineptr->Register(simage);//注册并返回一个人脸id
        if(faceid>=0){
            fengineptr->Save("./face.db");
        }
        return faceid;
    }
}

int QFaceObject::face_query(cv::Mat &faceImage)//人脸查询
{
    //把opencv的Mat数据转为seetaface的数据
    //qDebug()<<"0000";
    SeetaImageData simage;
    simage.data=faceImage.data;
    simage.width=faceImage.cols;
    simage.height=faceImage.rows;
    simage.channels=faceImage.channels();
    // 声明相似度变量
    float similarity=0;
    // 调用人脸引擎进行人脸识别
    int64_t faceID =fengineptr->Query(simage,&similarity);//运行时间较长

    //如果人脸可信度大于0.5，发送faceid信号
    if(similarity>=0.5)
    {
        emit send_faceid(faceID);
    }
    else
    {
        emit send_faceid(-1);
    }
    return faceID;
}
bool QFaceObject::delete_face_by_id(int64_t faceID)
{

    if (fengineptr->Delete(faceID)) {
        // 如果删除成功，保存修改后的数据库
        fengineptr->Save("./face.db");
        return true;
    }
    return false;
}


