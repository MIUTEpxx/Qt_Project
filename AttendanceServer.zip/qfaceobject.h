//封装人脸引擎对象
#ifndef QFACEOBJECT_H
#define QFACEOBJECT_H

#include <QObject>
//seetaface内含有人脸数据库 数据库包含人脸数据和对应的id
#include <seeta/FaceEngine.h> //FaceEngine包含数据库，人脸的注册，检测，识别等功能
#include <opencv.hpp>

//人脸数据存储，人脸检测，识别
class QFaceObject : public QObject
{
    Q_OBJECT
public:
    explicit QFaceObject(QObject *parent = nullptr);
    ~QFaceObject();

public slots:
    int64_t face_register(cv::Mat& faceImage);//人脸注册 注册成功后返回对应id 失败返回-1
    int face_query(cv::Mat& faceImage);//人脸查询，返回id号
    bool delete_face_by_id(int64_t faceID);//删除对应人脸数据
    void reLoad();
    void Load();
signals:
    void send_faceid(int64_t faceid);
private:
     // seeta 人脸引擎指针
    seeta::FaceEngine *fengineptr;
};

#endif // QFACEOBJECT_H
