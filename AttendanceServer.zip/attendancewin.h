#ifndef ATTENDANCEWIN_H
#define ATTENDANCEWIN_H

#include <QMainWindow>
#include <QTcpSocket>
#include <QTcpServer>
#include "qfaceobject.h"
#include <opencv.hpp>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QDateTime>
QT_BEGIN_NAMESPACE
namespace Ui { class AttendanceWin; }
QT_END_NAMESPACE

class AttendanceWin : public QMainWindow
{
    Q_OBJECT

public:
    AttendanceWin(QWidget *parent = nullptr);
    ~AttendanceWin();
protected slots:
    void accept_client();
    void read_data();
    void recevice_faceID(int64_t);
    void connectDataBase();
signals:
    //人脸查询信号
    void query_(cv::Mat &image);
private:
    Ui::AttendanceWin *ui;
    // TCP服务器对象
    QTcpServer  mserver;
     // 与客户端通信的套接字对象
    QTcpSocket *msocket;
    quint64 bsize;

    QFaceObject fobj;
    QSqlTableModel model;
};
#endif // ATTENDANCEWIN_H
