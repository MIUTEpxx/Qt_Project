#include "attendancewin.h"
#include "ui_attendancewin.h"
#include "sqlform.h"
#include <QThread>
#include <QFile>
#include <QBuffer>
#include <QJsonObject>
#include <QSqlQuery>
#include <QDebug>
AttendanceWin::AttendanceWin(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::AttendanceWin)
{
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":/res/AttendanceServer_Logo.png"));//设置图标
    //QTcpServer当有客户端连接会发送newConnection 并将其连接到 accept_client 槽函数
    connect(&mserver,&QTcpServer::newConnection,this,&AttendanceWin::accept_client);

    // 监听指定的IP地址和端口，启动TCP服务器
    mserver.listen(QHostAddress::Any,9999);
    bsize = 0;

    //给模型sql绑定表格
    model.setTable("employee");

    //-----------------创建线程-----------------
    // 使用 face_query 函数查询人脸，获取人脸ID 这句代码资源消耗很大
    //int faceID = m_faceobject.face_query(faceImage);
    //我们在构造函数里创建线程，把QfaceObject的对象放入线程
    //但是在线程中不能直接调用对象的函数，需要用信号来触发
    QThread *thread=new QThread();
    //把QfaceObject的对象移动到线程中执行
    fobj.moveToThread(thread);
    //启动线程
    thread->start();

    //绑定查询槽函数 人脸查询信号
    connect(this,&AttendanceWin::query_,&fobj,&QFaceObject::face_query);

    //关联QFaceObject中的send_faceid信号
    connect(&fobj,&QFaceObject::send_faceid,this,&AttendanceWin::recevice_faceID);

    //数据库被修改后 重新绑定
    connect(ui->tab_2,&SQLForm::sqlChange,this,&AttendanceWin::connectDataBase);
    connect(ui->tab_2,&SQLForm::sqlChange,&fobj,&QFaceObject::Load);
    connect(ui->registerWidget,&RegisterWin::newRegistrations,this,&AttendanceWin::connectDataBase);
    connect(ui->registerWidget,&RegisterWin::newRegistrations,&fobj,&QFaceObject::reLoad);
    connect(ui->tab_2,&SQLForm::sqlChange,ui->registerWidget,&RegisterWin::initdata);
}
void AttendanceWin::connectDataBase()
{
    // 重新绑定表格
    model.setTable("employee");
    // 重新加载表格数据
    model.select();
}
AttendanceWin::~AttendanceWin()
{
    delete ui;
}

//接受客户端连接
void AttendanceWin::accept_client()
{
//获取与客户端通信的套接字：
    msocket =mserver.nextPendingConnection();
    //当客户端有数据到达，套接字准备好读取数据时，会发送readyRead信号 并将其连接到 read_data 槽函数
    connect(msocket,&QTcpSocket::readyRead,this,&AttendanceWin::read_data);
}


//读取客户端发送的数据
void AttendanceWin::read_data(){

    /* test
    QString msg = msocket->readAll();
    qDebug()<<msg;
    */

    QDataStream stream(msocket);// 创建 QDataStream对象 把套接字绑定到数据流
    stream.setVersion(QDataStream::Qt_5_14);//版本与发送端一致

    // 如果 bsize 为零，则检查套接字中是否有足够的数据读取数据大小
    if(bsize==0){
        //当读取数据大小时，QDataStream 会将数据转换为 qint64 类型
        if(msocket->bytesAvailable()<(quint64)sizeof(bsize)) return;// 数据不足，返回

        //采集数据长度
        stream>>bsize;
    }

    // 检查套接字中是否有足够的数据读取图像数据
    if(msocket->bytesAvailable() < bsize)//说明数据还没有发送完成 返回继续等
        return;

     // 读取图像数据并将其赋予 data
    QByteArray data;
    stream>>data; //采集图像数据
    // 将 bsize 重置为零
    bsize=0;
    if(data.size()==0){//没读到数据
        return;
    }
    //显示图片
    QPixmap mmp;
    // 使用 loadFromData() 函数从 data 中加载图像
    mmp.loadFromData(data,"jpg");
    // 将图像缩放到 QLabel 控件的大小
    mmp=mmp.scaled(ui->picLb->size());
    // 将图像显示在 QLabel 控件上
    ui->picLb->setPixmap(mmp);

    //识别人脸
    cv::Mat faceImage;

    //data: QByteArray -> vector<uchar>
    std::vector<uchar> decode;
    decode.resize(data.size());
    memcpy(decode.data(),data.data(),data.size());
    //data->faceImage 字节流数据转化为矩阵
    faceImage=cv::imdecode(decode,cv::IMREAD_COLOR);
    //int faceid=fobj.face_query(faceImage);
    emit query_(faceImage);//qt中信号无法直接传递cv::Mat类型数据，得先注册
}

#if 0
void AttendanceWin::recevice_faceID(int64_t faceid)
{
    qDebug()<<"faceID= "<<faceid;

    if(faceid < 0)//没有检测到人脸，也得发送空的数据
    {
        QString sdmsg=QString("{\"employeeID\":\"%1\",\"name\":\"%2\",\"department\":\"浙工商\",\"time\":\"%3\",\"faceid\":\"%4\",\"image\":\"%5\"}")
                .arg(QString("未识别")).arg(QString("未识别"))
                .arg(QDateTime::currentDateTime().toString("yyyy-mm-dd hh:mm:ss")).arg(QString("%1").arg(faceid)).arg(0);
        msocket->write(sdmsg.toUtf8());
        return;
    }

    QString headfile = QString("./data/%1.jpg").arg(faceid);
    QByteArray base64ImageData=0;

    if (QFile::exists(headfile)) {
        // 读取图片文件
        QFile file(headfile);
        if (file.open(QIODevice::ReadOnly)) {
            // 将图片文件转换为QImage
            QImage image;
            image.load(&file, "JPEG"); // 假设图片是JPEG格式

            // 缩放图片到512x512大小
            image = image.scaled(512, 512, Qt::KeepAspectRatio, Qt::SmoothTransformation);

            // 将缩放后的图片保存到QByteArray
            QByteArray imageData;
            QBuffer buffer(&imageData);
            buffer.open(QIODevice::WriteOnly);
            image.save(&buffer, "JPEG"); // 保存为JPEG格式

            // 将图片数据转换为Base64编码的字符串
            base64ImageData = QByteArray::fromBase64(imageData);
            buffer.close();
            file.close();
            qDebug()<<"______图像数据：\n"<<base64ImageData;
            QString headfile1 = "./data/image_test.jpg";
            QFile file(headfile1);
            if (file.open(QIODevice::WriteOnly)) {
                file.write(base64ImageData);
                file.close();
            }
        } else {
            qDebug() << "Unable to open image file:" << headfile;
        }
    } else {
        qDebug() << "Image file does not exist:" << headfile;
    }

    //从数据库查询对应数据
    //给模型设置过滤器
    model.setFilter(QString("faceID=%1").arg(faceid));
    //查询
    model.select();
    //判断是否查询到数据
    if(model.rowCount()==1){
        // 数据传递给客户端
        //工号，姓名，部门，时间
        //{"employeeID":%1,"name":%2,"department":"软件","time":%3}

        QString base64String = base64ImageData.toBase64(); // 将Base64编码转换为字符串

        QSqlRecord record = model.record(0);

        QString sdmsg=QString("{\"employeeID\":\"%1\",\"name\":\"%2\",\"department\":\"浙工商\",\"time\":\"%3\",\"faceid\":\"%4\",\"image\":\"%5\"}")
                .arg(record.value("employeeID").toString()).arg(record.value("name").toString())
                .arg(QDateTime::currentDateTime().toString("yyyy-mm-dd hh:mm:ss")).arg(QString("%1").arg(faceid)).arg(QString("%1").arg(base64String));
        msocket->write(sdmsg.toUtf8());//把打包好的数据发送给客户端


        //把数据写入考勤表数据库
    }
}
#endif
#if 1
void AttendanceWin::recevice_faceID(int64_t faceid)
{
    qDebug()<<"faceID= "<<faceid;

    if(faceid < 0)//没有检测到人脸，也得发送空的数据
    {
        QString sdmsg=QString("{\"1\":\"%1\",\"2\":\"%2\",\"3\":\" %3\",\"4\":\"%4\",\"5\":\"%5\",\"6\":\"%6\",\"7clock\":\"%7\"}")
                .arg(QString("未识别")).arg(QString("未识别")).arg(QString("未识别"))
                .arg(QDateTime::currentDateTime().toString("yyyy-mm-dd hh:mm:ss"))
                .arg(QString("%1").arg(faceid)).arg(0).arg(-1);
        msocket->write(sdmsg.toUtf8());
        return;
    }

    QString headfile = QString("./data/%1.jpg").arg(faceid);
    QString base64String;
    if (QFile::exists(headfile)) {
        // 读取图片文件
        QFile file(headfile);
        if (file.open(QIODevice::ReadOnly)) {
            // 将图片文件转换为QImage
            QImage image;
            image.load(&file, "JPEG"); // 假设图片是JPEG格式

            // 缩放图片到512x512大小
            image = image.scaled(512, 512, Qt::KeepAspectRatio, Qt::SmoothTransformation);

            // 将缩放后的图片保存到QByteArray
            QByteArray imageData;
            QBuffer buffer(&imageData);
            buffer.open(QIODevice::WriteOnly);
            image.save(&buffer, "JPEG"); // 保存为JPEG格式

            base64String = QString::fromLocal8Bit(imageData.toBase64());//将Base64编码转换为字符串
            buffer.close();
            file.close();
        } else {
            qDebug() << "Unable to open image file:" << headfile;
        }
    } else {
        qDebug() << "Image file does not exist:" << headfile;
    }


    //从数据库查询对应数据
    //给模型设置过滤器
    model.setFilter(QString("faceID=%1").arg(faceid));
    //查询
    model.select();


    //判断是否查询到数据
    if(model.rowCount()==1){
        // 数据传递给客户端
        //工号，姓名，部门，时间
        //{"employeeID":%1,"name":%2,"department":"软件","time":%3}
        QSqlQuery query;
        ///获取表前三列信息///vvvvvvvvvvvvvv
        query.prepare("PRAGMA table_info(employee)");
        if (!query.exec()) {
            qDebug() << "Error retrieving table information:" << query.lastError().text();
            return;
        }
        // 使用 QStringList 来存储列名
        QStringList columnNames;
        int columnCount = 0;

        // 遍历查询结果，获取列信息
        while (query.next() && columnCount<3) {
            QString columnName = query.value("name").toString();
            columnNames.append(columnName);
            columnCount++;
        }
        //qDebug()<<"columnCount"<<columnCount;
        ///获取表的前三列信息///^^^^^^^^^^^
        QSqlRecord record = model.record(0); // 获取查询到的第一条记录

        // 查询attendance表中是否已经打卡
        QString selectSql = QString("SELECT COUNT(*) FROM attendance WHERE %1 = '%2'")
                .arg(columnNames[0]).arg(record.value(columnNames[0]).toString());
        if (!query.exec(selectSql)) {
            qDebug() << query.lastError().text() << 444; // 输出错误信息
            return ;
        }

        // 检查查询结果
        int count = 0;
        int attendanceStatus;//考勤状态:-1.未识别  0.未打卡  1.已打卡  3.打卡失败
        if (query.next()) {
            count = query.value(0).toInt();
        }
        if (count > 0) {
            qDebug() << "已打卡";
            attendanceStatus=1;
        } else {
            qDebug() << "未打卡";
            attendanceStatus=0;
        }
        qDebug()<<"count "<<count;
///test///
//        QString sdmsg = QString("{\"%1\":\"%2\",\"%3\":\"%4\",\"%5\":\"%6\",\"time\":\"%7\",\"faceid\":\"%8\",\"image\":\"%9\"}")
//                        .arg("employeeID").arg("12345") // 示例员工ID
//                        .arg("name").arg("张三") // 示例员工姓名
//                        .arg("department").arg("技术部") // 示例部门
//                        .arg(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss")) // 时间
//                        .arg(QString("%1").arg(faceid)) // faceid
//                        .arg(QString("%1").arg(base64String)); // Base64编码的图片数据
//////////

//        QString sdmsg=QString("{\"employeeID\":\"%1\",\"name\":\"%2\",\"department\":\"%3\",\"time\":\"%4\",\"faceid\":\"%5\",\"image\":\"%6\"}")
//                .arg(record.value("employeeID").toString()).arg(record.value("name").toString()).arg(record.value("department").toString())
//                .arg(QDateTime::currentDateTime().toString("yyyy-mm-dd hh:mm:ss")).arg(QString("%1").arg(faceid)).arg(QString("%1").arg(base64String));
        //msocket->write(sdmsg.toUtf8());//把打包好的数据发送给客户端


        if(attendanceStatus==0)//未打卡
        {
            //把数据写入考勤表数据库
            //时间是系统默认生成不需要加入
            QString insertstr = QString("insert into attendance(%1,%2,%3) values('%4','%5','%6')")
                    .arg(columnNames[0]).arg(columnNames[1]).arg(columnNames[2]).arg(record.value(columnNames[0])
                    .toString()).arg(record.value(columnNames[1]).toString()).arg(record.value(columnNames[2]).toString());

            //qDebug()<<insertstr;
            //QSqlQuery query;
            if(query.exec(insertstr))
            {
                // 数据插入数据库发送正确数据到客户端
                //msocket->write(sdmsg.toUtf8());
            }
            else{
                //考勤失败
                //QString sdmsg=QString("{\"employeeID\":\"%1\",\"name\":\"%2\",\"department\":\"浙工商\",\"time\":\"%3\",\"faceid\":\"%4\",\"image\":\"%5\"}")
                //        .arg(QString("考勤失败")).arg(QString(""))
                //        .arg(QDateTime::currentDateTime().toString("yyyy-mm-dd hh:mm:ss")).arg(QString("%1").arg(faceid)).arg(base64String);
               // 发送数据
                //msocket->write(sdmsg.toUtf8());
                attendanceStatus=3;
            }
        }
        QString sdmsg=QString("{\"1%1\":\"%2\",\"2%3\":\"%4\",\"3%5\":\"%6\",\"4time\":\"%7\",\"5faceid\":\"%8\",\"6image\":\"%9\",\"7clock\":\"%10\"}")
                .arg(columnNames[0]).arg(record.value(columnNames[0]).toString()).arg(columnNames[1]).arg(record.value(columnNames[1]).toString())
                .arg(columnNames[2]).arg(record.value(columnNames[2]).toString()).arg(QDateTime::currentDateTime().toString("yyyy-mm-dd hh:mm:ss"))
                .arg(QString("%1").arg(faceid)).arg(QString("%1").arg(base64String)).arg(attendanceStatus);
       msocket->write(sdmsg.toUtf8());
    }
}


#endif
