#include "registerwin.h"
#include "ui_registerwin.h"


RegisterWin::RegisterWin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RegisterWin)
{
    ui->setupUi(this);
    ID="";
    // 断开自动生成的连接 确保connect(ui->registerBtn,&QPushButton::clicked,[=](){});优先执行
    disconnect(ui->registerBtn, nullptr, this, nullptr);
    initdata();
    // 重新连接自动生成的槽函数
    connect(ui->registerBtn, &QPushButton::clicked, this, &RegisterWin::on_registerBtn_clicked);

    connect(ui->resetBtn,&QPushButton::clicked,[=](){initdata();});
}

RegisterWin::~RegisterWin()
{
    delete ui;
}
void clearScrollArea(QScrollArea *scrollArea) {
    QWidget *widget = scrollArea->takeWidget(); // 获取中心控件

    if (widget) {
        // 如果中心控件有布局，清除布局中的所有控件
        QLayout *layout = widget->layout();
        if (layout) {
            QLayoutItem *item;
            while ((item = layout->takeAt(0)) != nullptr) {
                if (item->widget()) {
                    delete item->widget();
                }
                delete item;
            }
            delete layout; // 删除布局
        } else {
            // 如果没有布局，直接删除中心控件中的所有子控件
            QList<QWidget*> widgets = widget->findChildren<QWidget*>();
            for (QWidget *w : widgets) {
                delete w;
            }
        }

        // 删除中心控件
        delete widget;
    }

    // 重新设置中心控件为nullptr
    scrollArea->setWidget(nullptr);
}
//void RegisterWin::initdata()
//{
//    data.clear();
//    ui->headPicLb->clear();
//    clearScrollArea(ui->scrollArea);
//    //2.把个人信息存储到数据库employee
//    model.setTable("employee");//设置表名
//    record=model.record();

//    QSqlQuery query;
//    query.prepare("PRAGMA table_info(employee)");
//    if (!query.exec()) {
//        qDebug() << "Error retrieving table information:" << query.lastError().text();
//        return;
//    }

//    // 使用 QStringList 来存储列名
//    QStringList columnNames;
//    int columnCount = 0;
//    QWidget *contentWidget = new QWidget(); // QScrollArea 的中心控件
//    QVBoxLayout *mainLayout = new QVBoxLayout(contentWidget); // 主垂直布局
//    QHBoxLayout *layout1[100];
//    QLabel *label1[100];
//    QLineEdit *lineEdit1[100];
//    //设置数据

//    // 遍历查询结果，获取列信息
//    int i=0;
//    while (query.next()) {
//        QString columnName = query.value("name").toString();
//        if(columnName=="faceID") break;
//        if(ID=="")ID=columnName;
//        columnNames.append(columnName);
//        columnCount++;
//        layout1[i] = new QHBoxLayout();
//        label1[i] = new QLabel(columnName);
//        lineEdit1[i] = new QLineEdit();
//        layout1[i]->addWidget(label1[i]);
//        layout1[i]->addWidget(lineEdit1[i]);
//        mainLayout->addLayout(layout1[i]); // 将水平布局添加到主垂直布局中

////        connect(ui->registerBtn,&QPushButton::clicked,this,[=](){
////           data.append({columnNames[i],lineEdit1[i]->text()});
////           lineEdit1[i]->clear();
////           //qDebug()<<columnNames[i]<<" "<<lineEdit1->text();
////           // qDebug()<<i<<"---";
////        });
//        i++;
//    }
//     connect(ui->refreshButton,&QPushButton::clicked,[=](){
//        for(int j=0;j<i;j++){
//           delete layout1[i];
//           delete label1[i];
//           delete lineEdit1[i];
//        }
//        initdata();
//     });
//    // 设置 QScrollArea 的中心控件
//    ui->scrollArea->setWidget(contentWidget);
//}
void RegisterWin::initdata()
{
    //data.clear();
    columnNames.clear();
    ui->headPicLb->clear();
    clearScrollArea(ui->scrollArea);
    //2.把个人信息存储到数据库employee
    model.setTable("employee");//设置表名
    //record=model.record();

    QSqlQuery query;
    query.prepare("PRAGMA table_info(employee)");
    if (!query.exec()) {
        qDebug() << "Error retrieving table information:" << query.lastError().text();
        return;
    }

    // 使用 QStringList 来存储列名

    columnCount = 0;
    QWidget *contentWidget = new QWidget(); // QScrollArea 的中心控件
    QVBoxLayout *mainLayout = new QVBoxLayout(contentWidget); // 主垂直布局
    //设置数据

    // 遍历查询结果，获取列信息
    while (query.next()) {
        QString columnName = query.value("name").toString();
        if(columnName=="faceID") break;
        if(ID=="")ID=columnName;
        columnNames.append(columnName);

        QHBoxLayout *layout1 = new QHBoxLayout();
        QLabel *label1 = new QLabel(columnName);
        lineEdit1[columnCount] = new QLineEdit();
        layout1->addWidget(label1);
        layout1->addWidget(lineEdit1[columnCount]);
        mainLayout->addLayout(layout1); // 将水平布局添加到主垂直布局中

//        connect(ui->registerBtn,&QPushButton::clicked,this,[=](){
//           data.append({columnNames[columnCount],lineEdit1[columnCount]->text()});
//           lineEdit1[columnCount]->clear();
//           //qDebug()<<columnNames[i]<<" "<<lineEdit1->text();
//           // qDebug()<<i<<"---";
//        });
        columnCount++;
    }
    // 设置 QScrollArea 的中心控件
    ui->scrollArea->setWidget(contentWidget);
}
void RegisterWin::timerEvent(QTimerEvent *e)
{
#if 1
    //获取摄像头数据并显示在注册界面上
    cv::Mat image0;
    if(cap.isOpened()){
        cap>>image0;
    }
    if(image0.data==nullptr) return;// 如果图像数据为空，则返回
    image=image0;
    //mat->QImage 将图像格式转换为Qt能够处理的格式
    cv::Mat rgbImage;
    cv::cvtColor(image,rgbImage,cv::COLOR_BGR2RGB);// 将图像从BGR格式转换为RGB格式（OpenCV默认的颜色通道顺序与Qt不同）
    QImage qImag(rgbImage.data,rgbImage.cols,rgbImage.rows,rgbImage.step1(),QImage::Format_RGB888);// 创建Qt的QImage对象
    cv::flip(rgbImage, rgbImage, 1); // 水平翻转图像，因为摄像头的图像可能是镜像的
    //在QT界面上显示
    QPixmap mmp=QPixmap::fromImage(qImag);// 将QImage转换为QPixmap
    mmp=mmp.scaledToWidth(ui->headPicLb->width());// 根据标签的宽度缩放图像
    ui->headPicLb->setPixmap(mmp);// 将图像显示在标签上
#endif
}





void RegisterWin::on_addpicBtn_clicked()
{
    int w=ui->headPicLb->width();
    //int h=ui->headPicLb->height();
    //qDebug()<<ui->headPicLb->width()<<" "<<ui->headPicLb->height()<<111;
    //通过文件对话框 选择图片路径
   QString filepath = QFileDialog::getOpenFileName(this);
   ui->picFileEdit->setText(filepath);

   //显示图片,在图片标签中显示缩放后的图片
      QPixmap mmp(filepath);
      mmp = mmp.scaledToWidth(w);
      // mmp = mmp.scaledToHeight(h);
      ui->headPicLb->setPixmap(mmp);
      // // 设置图片在标签中居中显示
      ui->headPicLb->setAlignment(Qt::AlignCenter);


}

void RegisterWin::on_registerBtn_clicked()
{
    //qDebug()<<"123456879";
    //1.通过照片结合faceObjiect模块得到faceID
    QFaceObject faceobj;
    cv::Mat image=cv::imread(ui->picFileEdit->text().toUtf8().data());
    int faceID=faceobj.face_register(image);
    qDebug()<<faceID;
    if(faceID==-1){
        QMessageBox::warning(this,"","未检测出人脸或该人脸已被注册\n请重新上传图片",QMessageBox::Ok);
        return;
    }
    //把头像保存在一个固定目录下
    QString headfile=QString("./data/%1.jpg").arg(faceID);
    cv::imwrite(headfile.toStdString(),image);

    //2.把个人信息存储到数据库employee
    QSqlTableModel model;
    model.setTable("employee");//设置表名
    QSqlRecord record=model.record();
    //设置数据
//    for(QPair<QString,QString> a:data){
//         record.setValue(a.first,a.second);//设置数据
////         qDebug()<<a.first<<" "<<a.second;
//    }
    for(int i=0;i<columnCount;i++){
        record.setValue(columnNames[i],lineEdit1[i]->text());//设置数据
        qDebug()<<"注册: "<<columnNames[i]<<" "<<lineEdit1[i]<<" "<<lineEdit1[i]->text();
    }
    record.setValue("faceID",faceID);
    record.setValue("headfile",headfile);
    //把记录插入到数据库中
    bool ret=model.insertRecord(0,record);
    //3.提示注册成功
    if(ret){
        QMessageBox::information(this,"注册提示","注册成功");
        ui->headPicLb->clear();
        ui->picFileEdit->clear();
        emit newRegistrations();
        //提交
        model.submitAll();
    }else{
        QMessageBox::information(this,"注册提示","注册失败");
        faceobj.delete_face_by_id(faceID);
    }
}
void RegisterWin::on_vidoSwitchBtn_clicked()
{
    if(ui->vidoSwitchBtn->text()=="打开摄像头"){
        //打开摄像头//0表示打开默认摄像头
       if (cap.open(0)){
            ui->vidoSwitchBtn->setText("关闭摄像头");
            //启动定时器事件
            timerid=startTimer(100);
        }else{
           QMessageBox::warning(this, tr("错误"),tr("摄像头打开失败"));
         }

    }else{

        ui->vidoSwitchBtn->setText("打开摄像头");
        killTimer(timerid);//关闭定时器
        //关闭摄像头
        cap.release();
    }

}

void RegisterWin::on_cameraBtn_clicked()
{
    if(ui->vidoSwitchBtn->text()=="打开摄像头"){
        QMessageBox::information(this,"提示","请先打开摄像头",QMessageBox::Ok);
        return;
    }
    //保存数据
    QString headfile = QString("./data/%1.jpg").arg(QString(ID.toUtf8().toBase64()));
    cv::imwrite(headfile.toStdString(),image);
    ui->picFileEdit->setText(headfile);
    killTimer(timerid); // 停止定时器
    ui->vidoSwitchBtn->setText("打开摄像头"); // 设置按钮文本为“打开摄像头”
    // 关闭摄像头
    cap.release(); // 释放摄像头资源
    QMessageBox::information(nullptr,"信息","拍照成功");

}

#if 0
void RegisterWin::on_registerBtn_clicked()
{
    //1.通过照片结合faceObjiect模块得到faceID
    QFaceObject faceobj;
    cv::Mat image=cv::imread(ui->picFileEdit->text().toUtf8().data());
    int faceID=faceobj.face_register(image);
    qDebug()<<faceID;
    //把头像保存在一个固定目录下
    QString headfile=QString("./data/%1.jpg").arg(faceID);
    cv::imwrite(headfile.toStdString(),image);

    //2.把个人信息存储到数据库employee
    QSqlTableModel model;
    model.setTable("employee");//设置表名
    QSqlRecord record=model.record();
    //设置数据
    record.setValue("name",ui->nameEdit->text());
    record.setValue("sex",ui->mrb->isChecked()?"男":"女");
    record.setValue("birthday",ui->birthdayEdit->text());
    record.setValue("department",ui->departmentEdit->text());
    record.setValue("phone",ui->phoneEdit->text());
    record.setValue("faceID",faceID);
    record.setValue("headfile",headfile);
    //把记录插入到数据库中
    bool ret=model.insertRecord(0,record);
    //3.提示注册成功
    if(ret){
        QMessageBox::information(this,"注册提示","注册成功");
        //提交
        model.submitAll();
    }else{
        QMessageBox::information(this,"注册提示","注册失败");
    }
}
#endif
