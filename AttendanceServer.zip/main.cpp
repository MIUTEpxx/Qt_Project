#include "attendancewin.h"

#include<QDir>
#include <QApplication>
#include<QSqlDatabase>//使用qt自带数据库QSQLITE
#include<QSqlError>//用于数据库排查错误
#include<QSqlQuery>//数据库查询
#include"registerwin.h"
#include<opencv.hpp>
#include "selectwin.h"
#include "sqlform.h"
#include "test_registerwin.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //qt非自带的类型需要经过注册才能通过信号传递
    qRegisterMetaType<cv::Mat>("cv::Mat&");
    qRegisterMetaType<cv::Mat>("cv::Mat");
    qRegisterMetaType<int64_t>("int64_t");

    //RegisterWin ww;//测试RegisterWin窗口
    //ww.show();

    // 获取当前目录
    QDir currentDir = QDir::current();

    // 创建名为 "data" 的文件夹
    if (!currentDir.exists("data")) {
        if (!currentDir.mkdir("data")) {
            qDebug() << "创建data文件夹失败,请手动创建";
            return -1;
        } else {
            qDebug() << "data文件夹创建成功";
        }
    }

    //连接数据库
    QSqlDatabase db =QSqlDatabase::addDatabase("QSQLITE");
    //设置数据库名称
    db.setDatabaseName("server.db");
    if(!db.open()){
        qDebug()<<db.lastError().text()<<111;//输出错误信息
        return -1;
    }
    //创建员工信息表
    QString createsql="create table if not exists employee(employeeID varchar(32) primary key,name varchar(32),sex varchar(32),"
                     "birthday text,department text,phone text,faceID integer unique,headFile text)";
    QSqlQuery query;
    if(!query.exec(createsql)){
        qDebug()<<query.lastError().text()<<222;//输出错误信息
        return -1;
    }
    //创建考勤表
    createsql="create table if not exists attendance(attendanceID integer primary key autoincrement,employeeID varchar(32),name varchar(32),sex varchar(32),"
              "attendanceTime TIMESTAMP NOT NULL DEFAULT(datetime('now', 'localtime')))";
    if(!query.exec(createsql)){
        qDebug()<<query.lastError().text()<<333;//输出错误信息
        return -1;
    }

//    SQLForm s;
//    s.show();
//    test_registerwin t;
//    t.show();
      AttendanceWin w;
      w.show();
    //SelectWin ss;
    //ss.show();
    return a.exec();
}
