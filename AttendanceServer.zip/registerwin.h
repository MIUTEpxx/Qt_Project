#ifndef REGISTERWIN_H
#define REGISTERWIN_H

#include <QWidget>
#include<opencv.hpp>//利用opencv打开摄像头
#include<QFileDialog>
#include<qfaceobject.h>
#include<QDebug>
#include<QPainter>
#include<QSqlTableModel>
#include<QSqlRecord>
#include<QMessageBox>
#include<QSqlQuery>
#include<QSqlError>//用于数据库排查错误
#include<QHBoxLayout>
#include<QLineEdit>
//#include <QMap>

namespace Ui {
class RegisterWin;
}

class RegisterWin : public QWidget
{
    Q_OBJECT

public:
    explicit RegisterWin(QWidget *parent = nullptr);
    ~RegisterWin();
    void timerEvent(QTimerEvent* e);
    void initdata();
private slots:
    void on_addpicBtn_clicked();

    void on_registerBtn_clicked();

    void on_vidoSwitchBtn_clicked();

    void on_cameraBtn_clicked();

private:
    Ui::RegisterWin *ui;
    int timerid;
    cv::VideoCapture cap;// OpenCV 的视频捕获对象，用于访问摄像头
    cv::Mat image;
    QSqlTableModel model;
    //QSqlRecord record=model.record();
    QString ID;
    //QVector<QPair<QString,QString>> data;
    QLineEdit *lineEdit1[100];
    QStringList columnNames;
    int columnCount = 0;
signals:
    void newRegistrations();//注册新用户后发送信号重新连接数据库
};

#endif // REGISTERWIN_H
