#ifndef TEST_REGISTERWIN_H
#define TEST_REGISTERWIN_H

#include <QWidget>
#include <QListWidgetItem>
#include <QDateTime>
#include <QSqlRecord>
#include <QFile>
#include <QMessageBox>
#include <QDebug>
#include<QSqlDatabase>//使用qt自带数据库QSQLITE
#include<QSqlError>//用于数据库排查错误
#include<QSqlQuery>//数据库查询
#include<QSqlTableModel>

namespace Ui {
class test_registerwin;
}

class test_registerwin : public QWidget
{
    Q_OBJECT

public:
    explicit test_registerwin(QWidget *parent = nullptr);
    ~test_registerwin();
    void initdata();

private slots:
    void on_registerBtn_clicked();

private:
    Ui::test_registerwin *ui;
    //2.把个人信息存储到数据库employee
    QSqlTableModel model;
    QSqlRecord record=model.record();
    QVector<QPair<QString,QString>> data;
};

#endif // TEST_REGISTERWIN_H
